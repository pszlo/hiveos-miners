#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

	[[ -z $CUSTOM_USER_CONFIG ]] && echo -e "${YELLOW}Custom alghoritm is empty${NOCOLOR}" && return 1
	rm $CUSTOM_AUTOSWITCH_FILENAME
	conf=`echo $CUSTOM_URL | grep -aob 'BENCHMARKS' | grep -oE '[0-9]+'`
	if [ ! -z "$conf" ]; then
		#autoswitch
		cp -f $CUSTOM_AUTOSWITCH_TEMPLATE $CUSTOM_AUTOSWITCH_FILENAME
		sed -i "s/%WAL%/${CUSTOM_TEMPLATE}/" $CUSTOM_AUTOSWITCH_FILENAME
		sed -i "s/%WORKER_NAME%/${WORKER_NAME}/" $CUSTOM_AUTOSWITCH_FILENAME
		sed -i "s/%REGION%/${CUSTOM_PASS}/" $CUSTOM_AUTOSWITCH_FILENAME
		echo $CUSTOM_URL | sed 's/; /\n/g' | sed 's/;/\n/g' > /hive/custom/excavator/benchmarks.json
		sed -i "45r /hive/custom/excavator/benchmarks.json" $CUSTOM_AUTOSWITCH_FILENAME
#		echo "" > $CUSTOM_CONFIG_FILENAME
	fi
	#user config
	#read config template
	conf=$CUSTOM_USER_CONFIG
	#replace values
	[[ -n $WORKER_NAME ]] && conf=$(sed "s/%WORKER_NAME%/$WORKER_NAME/g" <<< "$conf")
	[[ -n $CUSTOM_ALGO ]] && conf=$(sed "s/%CUSTOM_ALGO%/$CUSTOM_ALGO/g" <<< "$conf")
	#save config file
	echo $conf | jq . > $CUSTOM_CONFIG_FILENAME

