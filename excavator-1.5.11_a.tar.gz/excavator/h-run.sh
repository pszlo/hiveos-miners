#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_TEMPLATE ]] && echo -e "${RED}No CUSTOM_CONFIG_TEMPLATE is set${NOCOLOR}" #&& exit 1

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`

[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR
#[[ -d $CUSTOM_LOG_BASEDIR ]] && cp -f /hive/custom/$CUSTOM_NAME/excavator $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME

#cd $CUSTOM_LOG_BASEDIR

[[ ! -f "/hive/custom/$CUSTOM_NAME/excavator_1.5.11a_amd64.deb" ]] && wget "https://github.com/nicehash/excavator/releases/download/v1.5.11a/excavator_1.5.11a_amd64.deb"
[[ "excavator_1.5.11a_amd64.deb: OK" != `md5sum -c /hive/custom/$CUSTOM_NAME/excavator_1.5.11a_amd64.deb.md5` ]] && echo -e "${RED}md5 check error for excavator_1.5.11a_amd64.deb${NOCOLOR}" && exit 1
[[ ! -f /hive/custom/$CUSTOM_NAME/opt/excavator/bin/excavator ]] &&  dpkg --extract excavator_1.5.11a_amd64.deb .
cd "/hive/custom/$CUSTOM_NAME/opt/excavator/bin/"
[[ "excavator: OK" != `md5sum -c /hive/custom/$CUSTOM_NAME/opt/excavator/bin/excavator.md5` ]] && cd "/hive/custom/$CUSTOM_NAME" && dpkg --extract excavator_1.5.11a_amd64.deb .
cd "/hive/custom/$CUSTOM_NAME/opt/excavator/bin/"
[[ "excavator: OK" != `md5sum -c /hive/custom/$CUSTOM_NAME/opt/excavator/bin/excavator.md5` ]] && echo -e "${RED}md5 check error for excavator${NOCOLOR}" && exit 1


if [ -f $CUSTOM_AUTOSWITCH_FILENAME ]; then
  echo $CUSTOM_CONFIG_FILENAME > /var/log/run.log
  ./excavator -d $CONSOLE_LOG_LEVEL -f $FILE_LOG_LEVEL -wp $WEB_PORT -wi $WEB_HOST -wa $WEB_AUTH_TOKEN -fn $CUSTOM_LOG_BASENAME.log -c $CUSTOM_CONFIG_FILENAME & $CUSTOM_AUTOSWITCH_FILENAME
  # & /hive/custom/excavator/autoswitch.sh
else
  ./excavator -d $CONSOLE_LOG_LEVEL -f $FILE_LOG_LEVEL -p 0 -wp $WEB_PORT -wi $WEB_HOST -wa $WEB_AUTH_TOKEN -fn $CUSTOM_LOG_BASENAME.log -c $CUSTOM_CONFIG_FILENAME
fi
