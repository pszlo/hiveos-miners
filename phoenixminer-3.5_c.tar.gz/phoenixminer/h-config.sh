#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

coin=`echo $META | jq -r '.custom.coin' | awk '{print tolower($0)}'`

[[ -z ${coin} ]] && coin="auto"

[[ ! -z ${coin} ]] && coin="-coin ${coin}"

. /hive/custom/${CUSTOM_NAME}/h-manifest.conf
#CUSTOM_CONFIG_FILENAME=/hive/custom/${CUSTOM_NAME}/config.txt
#EPOOLS_FILENAME=/hive/custom/${CUSTOM_NAME}/epools.txt
USER_CONFIG_SEPARATOR="### USER CONFIG ###"

cat /hive/custom/${CUSTOM_NAME}/config_global.txt > $CUSTOM_CONFIG_FILENAME || echo -e "${YELLOW}WORKER_NAME not set${NOCOLOR}"
echo "-mport $WEB_PORT" >> $CUSTOM_CONFIG_FILENAME

[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1
echo "Creating epools.txt"
echo "$CUSTOM_URL" > $EPOOLS_FILENAME

	[[ ! -z $WORKER_NAME ]] && sed -i "s/%WORKER_NAME%/$WORKER_NAME/g" $EPOOLS_FILENAME

if [[ ! -z $CUSTOM_USER_CONFIG ]]; then
	echo "$USER_CONFIG_SEPARATOR" >> $CUSTOM_CONFIG_FILENAME
	echo "Appending user config";
	echo "$CUSTOM_USER_CONFIG" >> $CUSTOM_CONFIG_FILENAME
	[[ ! -z $WORKER_NAME ]] && sed -i "s/%WORKER_NAME%/$WORKER_NAME/g" $CUSTOM_CONFIG_FILENAME
fi
