#!/usr/bin/env bash

#######################
# MAIN script body
#######################

. /hive/custom/$CUSTOM_MINER/h-manifest.conf

url=http://${WEB_HOST}:${WEB_PORT}/api?command={\"id\":1,\"method\":\"algorithm.list\",\"params\":[]}
stats_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' -g $url`
if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner from localhost:${WEB_PORT}${NOCOLOR}"
else
	khs=`echo $stats_raw | jq -r '.algorithms[0].speed' | awk '{print $1/1000}'`
	local temp=$(jq '.temp' <<< $gpu_stats)
	local fan=$(jq '.fan' <<< $gpu_stats)
	local ac=$(jq '.algorithms[0].accepted_shares' <<< "$stats_raw")
	local rj=$(jq '.algorithms[0].rejected_shares' <<< "$stats_raw")
	local upt $(jq '.algorithms[0].uptime' <<< "$stats_raw")
	
	local hs=
	url=http://${WEB_HOST}:${WEB_PORT}/api?command={\"id\":1,\"method\":\"worker.list\",\"params\":[]}
	workers_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' -g $url`
	if [[ $workers_raw -ne 0 || -z $workers_raw ]]; then
		echo -e "${YELLOW}Failed to read $miner from localhost:${WEB_PORT}${NOCOLOR}"
        else
		local j=0
		for i in $(jq .workers[].device_id <<< "$workers_raw"); do
                        speed=`echo $(jq '.workers['$j'].algorithms[0].speed' <<< "$workers_raw") | awk '{printf "%.0f\n",$1}'`
                        hs[$i]=$((${hs[$i]} + $speed))
			((j++))
	        done
	fi
	
	stats=$(jq --argjson temp "$temp" \
				--argjson fan "$fan" \
				--arg ac "$ac" \
				--arg rj "$rj" \
				--argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
		'{$hs, algo: .algo, $temp, $fan, uptime: .connection.uptime, ar: [$ac, $rj]}' <<< "$stats_raw")
fi

	[[ -z $khs ]] && khs=0
	[[ -z $stats ]] && stats="null"

